//
//  Participant.swift
//  New Social Inclusion App
//
//  Created by Mary Chopin on 4/21/17.
//  Copyright © 2017 David Chopin. All rights reserved.
//

import UIKit

// Still a lot of unknown about the needs of the participant entiry and what methods are required

struct Participant {
    var name: String
    var email: String
    var code: String
}
