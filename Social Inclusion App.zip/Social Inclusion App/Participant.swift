//
//  Participant.swift
//  Social Inclusion App
//
//  Created by John Zaiss on 4/11/17.
//  Copyright © 2017 John Zaiss. All rights reserved.
//

import UIKit

// Still a lot of unknown about the needs of the participant entiry and what methods are required

struct Participant {
    var name: String
    var email: String
    var code: String
}
