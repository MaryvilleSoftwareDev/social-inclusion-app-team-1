//
//  ActivityCell.swift
//  Social Inclusion App
//
//  Created by Mary Chopin on 4/19/17.
//  Copyright © 2017 Maryville Information Systems. All rights reserved.
//

import UIKit

class ActivityCell: UICollectionViewCell {
    
    var activityName: String = ""
    var activityImage: UIImage?
    
    @IBOutlet weak var cellImage: UIImageView!
    
    @IBOutlet weak var cellActivityTitle: UILabel!
    
}
