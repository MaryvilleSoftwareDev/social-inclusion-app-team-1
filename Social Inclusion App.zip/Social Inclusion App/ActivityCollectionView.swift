//
//  ActivityCollectionView.swift
//  Social Inclusion App
//
//  Created by Mary Chopin on 4/19/17.
//  Copyright © 2017 Maryville Information Systems. All rights reserved.
//

import UIKit

let personalSkill: SocialSkills = SocialSkills(skillName: "personal skill", skillDetails: "a skill that has to do with yourself that can improve your social interaction")

let instruction = [Instructions(title: "Buy an instrument", details: "You may want to start with an affordable insrument", image: #imageLiteral(resourceName: "grand-piano"), startTimer: [Date()], stopTimer: [Date()], socialSkill: personalSkill, socialSkillText: "Personal skill")]

class ActivityCollectionView: UICollectionViewController {
    
    
    
    
    
    let activities = [Activity(name: "Learn Instrument", description: "You will play an instrument", icon: #imageLiteral(resourceName: "grand-piano"), category: "Personal skill", instructions: instruction), Activity(name: "Get Coffee", description: "You will go out and get some coffee", icon: #imageLiteral(resourceName: "coffee"), category: "Personal skill", instructions: instruction)]
    
    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return activities.count
    }
    
    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "collectionViewCell", for: indexPath) as? ActivityCell
        let item = activities[indexPath.row]
        
        cell?.cellImage.image = item.icon
        cell?.cellActivityTitle.text = item.name
        
        return cell!
        
    }

}


